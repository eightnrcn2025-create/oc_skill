#!/usr/bin/env bash
set -euo pipefail
export PATH="$HOME/.local/bin:$PATH"
cd /root/.openclaw/agents/laoba/workspace/.agents/skills/vendor-commission/scripts
node vendor-commission.js --report --year 2026 --month 2
