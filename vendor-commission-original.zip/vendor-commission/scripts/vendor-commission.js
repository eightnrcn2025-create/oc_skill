// vendor-commission.js v2.7
// 厂商佣金数据采集 — 从 config.json 读取配置，生成 Excel 并通过 TG Bot 发送
// 用法：
//   node vendor-commission.js                        # 自动判断当月/补跑
//   node vendor-commission.js --year 2026 --month 3  # 指定年月
//   node vendor-commission.js --report               # 生成 Excel 发送到 TG（按月查询时使用）
//   node vendor-commission.js --report --vendor ddgame  # 只处理指定厂商
//
// 环境变量（优先级高于 config.json）：
//   SITE_LOGIN_URL   SITE_USERNAME   SITE_PASSWORD   SITE_API_BASE
//   TG_BOT_TOKEN     TG_CHAT_ID

'use strict';
const path   = require('path');
const fs     = require('fs');
const https  = require('https');
const http   = require('http');
const { execSync } = require('child_process');

// ── 读取配置 ──────────────────────────────────────────────
const CONFIG_PATH = path.join(__dirname, '..', 'config.json');
const cfg = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf-8'));

// 白名单验证 playwright 路径
const playwrightWhitelist = [
  '/tmp/pw-test/node_modules/playwright',
  '/tmp/vendor-commission-deps/node_modules/playwright',
];
if (!playwrightWhitelist.includes(cfg.playwrightPath)) {
  throw new Error('[安全] playwright 路径不在白名单内: ' + cfg.playwrightPath);
}
const { chromium } = require(cfg.playwrightPath);
const C            = cfg.chromePath;
const FALLBACK_RATE = cfg.usdtFallbackRate || 7.2;
const OVERRIDES    = cfg.commissionOverrides?.rules || {};

// 敏感凭证：优先读环境变量，fallback 到 config（安装时引导用户设置环境变量）
const TG_TOKEN  = process.env.TG_BOT_TOKEN  || cfg.telegram?.botToken;
if (!TG_TOKEN)  throw new Error('TG_BOT_TOKEN 未配置，请设置环境变量或 config.json');
const TG_CHATID = process.env.TG_CHAT_ID    || cfg.telegram?.chatId;
if (!TG_CHATID) throw new Error('TG_CHAT_ID 未配置，请设置环境变量或 config.json');

// 汇率本地缓存文件
const RATE_CACHE_FILE = path.join(__dirname, '..', 'rate_cache.json');

// ── xlsx 模块自动探测 ─────────────────────────────────────
function loadXlsx() {
  // 白名单：仅允许预定义的安全路径
  const whitelist = [
    '/tmp/vendor-commission-deps/node_modules/xlsx',
    '/tmp/pw-test/node_modules/xlsx',
    '/tmp/gp-recon2/node_modules/xlsx',
  ];
  
  // 如果 config 提供了路径，验证是否在白名单内
  if (cfg.xlsxPath && !whitelist.includes(cfg.xlsxPath)) {
    console.warn('[安全] xlsx 路径不在白名单内，已忽略:', cfg.xlsxPath);
  }
  
  for (const p of whitelist) {
    try { return require(p); } catch (e) {}
  }
  return null;
}

// ── 工具函数 ──────────────────────────────────────────────
function fmtSheetName(n) {
  return n.replace(/[\\\/\?\*\[\]:]/g, '').slice(0, 31);
}

function toCST(utcStr) {
  if (!utcStr) return '';
  const d   = new Date(utcStr);
  const cst = new Date(d.getTime() + 8 * 3600 * 1000);
  return cst.toISOString().replace('T', ' ').slice(0, 19);
}

// ── 通用 HTTPS GET（替代 execSync curl） ─────────────────
function httpsGet(url, options = {}) {
  return new Promise((resolve, reject) => {
    const lib = url.startsWith('https') ? https : http;
    const req = lib.get(url, {
      timeout: 10000,
      headers: { 'User-Agent': 'Mozilla/5.0', ...options.headers },
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { reject(new Error('JSON parse error: ' + data.slice(0, 100))); }
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
  });
}

// ── 通用 HTTPS POST ───────────────────────────────────────
function httpsPost(url, body, headers = {}) {
  return new Promise((resolve, reject) => {
    const bodyStr = typeof body === 'string' ? body : JSON.stringify(body);
    const parsed  = new URL(url);
    const options = {
      hostname: parsed.hostname,
      path:     parsed.pathname + parsed.search,
      method:   'POST',
      timeout:  10000,
      headers: {
        'Content-Type':   'application/json',
        'Content-Length': Buffer.byteLength(bodyStr),
        'User-Agent':     'Mozilla/5.0',
        ...headers,
      },
    };
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { reject(new Error('JSON parse error')); }
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
    req.write(bodyStr);
    req.end();
  });
}

// ── 汇率本地缓存读写 ──────────────────────────────────────
function loadCachedRate() {
  try {
    if (fs.existsSync(RATE_CACHE_FILE)) {
      const c = JSON.parse(fs.readFileSync(RATE_CACHE_FILE, 'utf-8'));
      if (c.rate > 0) return c.rate;
    }
  } catch (e) {}
  return null;
}

function saveCachedRate(rate) {
  try {
    fs.writeFileSync(RATE_CACHE_FILE, JSON.stringify({
      rate,
      updatedAt: new Date().toISOString(),
    }), 'utf-8');
  } catch (e) {}
}

// ── 实时汇率：5个接口依次尝试（全用 https 模块，无 execSync） ──
// 汇率数据验证函数
function validateRate(rate, source) {
  const r = parseFloat(rate);
  // 合理范围：6.0 ~ 8.0 CNY/USDT（超出此范围视为异常）
  if (isNaN(r) || r < 6.0 || r > 8.0) {
    console.warn(`[安全] ${source} 返回汇率异常: ${rate}，已忽略`);
    return null;
  }
  return r;
}

async function getUsdtRate() {
  // 接口1：Binance P2P
  try {
    const data = await httpsPost(
      'https://p2p.binance.com/bapi/c2c/v2/friendly/c2c/adv/search',
      { asset: 'USDT', fiat: 'CNY', merchantCheck: false, page: 1, payTypes: [], publisherType: null, rows: 5, tradeType: 'SELL' }
    );
    const prices = (data?.data || [])
      .map(x => validateRate(x?.adv?.price, 'Binance P2P'))
      .filter(x => x !== null)
      .sort((a, b) => a - b);
    if (prices.length) {
      const mid = prices[Math.floor(prices.length / 2)];
      console.log('实时汇率（Binance P2P）1 USDT =', mid, 'CNY');
      saveCachedRate(mid);
      return mid;
    }
  } catch (e) {}

  // 接口2：OKX C2C
  try {
    const data = await httpsGet('https://www.okx.com/v3/c2c/otc-ticker/quotedPrice?side=buy&quoteCurrency=CNY&baseCurrency=USDT');
    const price = validateRate(data?.data?.[0]?.price, 'OKX C2C');
    if (price) {
      console.log('实时汇率（OKX C2C）1 USDT =', price, 'CNY');
      saveCachedRate(price);
      return price;
    }
  } catch (e) {}

  // 接口3：CoinGecko
  try {
    const data = await httpsGet('https://api.coingecko.com/api/v3/simple/price?ids=tether&vs_currencies=cny');
    const price = validateRate(data?.tether?.cny, 'CoinGecko');
    if (price) {
      console.log('实时汇率（CoinGecko）1 USDT =', price, 'CNY');
      saveCachedRate(price);
      return price;
    }
  } catch (e) {}

  // 接口4：fawazahmed0 Currency API
  try {
    const data = await httpsGet('https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usdt.json');
    const price = validateRate(data?.usdt?.cny, 'fawazahmed0');
    if (price) {
      console.log('实时汇率（fawazahmed0）1 USDT =', price, 'CNY');
      saveCachedRate(price);
      return price;
    }
  } catch (e) {}

  // 接口5：ExchangeRate-API（CNY→USD 反推）
  try {
    const data = await httpsGet('https://open.er-api.com/v6/latest/CNY');
    const usdPerCny = parseFloat(data?.rates?.USD);
    if (usdPerCny > 0) {
      const price = validateRate((1 / usdPerCny).toFixed(4), 'ExchangeRate-API');
      if (price) {
        console.log('实时汇率（ExchangeRate-API）1 USDT =', price, 'CNY');
        saveCachedRate(price);
        return price;
      }
    }
  } catch (e) {}

  // 兜底1：上次成功缓存的汇率
  const cached = loadCachedRate();
  if (cached) {
    console.warn(`⚠️  所有实时接口均失败，使用上次缓存汇率 1 USDT = ${cached} CNY`);
    return cached;
  }

  // 兜底2：config.json 中的固定值
  console.warn(`⚠️  所有接口及缓存均失败，使用配置兜底值 1 USDT = ${FALLBACK_RATE} CNY`);
  return FALLBACK_RATE;
}

// ── Telegram 发送（使用 https 模块，去掉 execSync curl） ──
async function tgSendText(text) {
  if (!TG_TOKEN || !TG_CHATID) { console.log('[TG] 未配置 botToken/chatId，跳过'); return; }
  try {
    const r = await httpsPost(
      `https://api.telegram.org/bot${TG_TOKEN}/sendMessage`,
      { chat_id: TG_CHATID, text }
    );
    console.log(r.ok ? '[TG] 文字发送成功' : '[TG] 文字发送失败: ' + r.description);
  } catch (e) { console.error('[TG] 文字发送异常:', e.message); }
}

function tgSendDocument(filePath) {
  if (!TG_TOKEN || !TG_CHATID) { console.log('[TG] 未配置 botToken/chatId，跳过'); return; }
  
  // 路径规范化（解析符号链接，防穿越攻击）
  let realPath;
  try {
    realPath = fs.realpathSync(filePath);
  } catch (e) {
    console.error('[TG] 文件路径解析失败:', filePath, e.message);
    return;
  }
  
  // 严格验证：规范化后的真实路径必须在 /tmp/ 下
  if (!realPath.startsWith('/tmp/')) {
    console.error('[TG] 文件路径不合法（规范化后不在 /tmp/ 下）:', realPath);
    return;
  }
  
  // 验证文件名不含特殊字符
  const basename = path.basename(realPath);
  if (!/^[\w\u4e00-\u9fa5._-]+$/.test(basename)) {
    console.error('[TG] 文件名包含非法字符:', basename);
    return;
  }
  
  try {
    const r = JSON.parse(execSync(
      `curl -s -X POST "https://api.telegram.org/bot${TG_TOKEN}/sendDocument" -F "chat_id=${TG_CHATID}" -F "document=@${realPath}"`,
      { encoding: 'utf-8' }
    ));
    console.log(r.ok ? '[TG] 文件发送成功: ' + basename : '[TG] 文件发送失败: ' + r.description);
  } catch (e) { console.error('[TG] 文件发送异常:', e.message); }
}

// ── 登录（网页模拟） ──────────────────────────────────────
async function loginGetToken(site) {
  // 凭证优先读环境变量
  const loginUrl  = process.env.SITE_LOGIN_URL || site.loginUrl;
  const username  = process.env.SITE_USERNAME  || site.username;
  const password  = process.env.SITE_PASSWORD  || site.password;

  // 验证 URL 合法性
  if (!loginUrl || !/^https?:\/\//.test(loginUrl)) {
    throw new Error('登录 URL 非法: ' + loginUrl);
  }
  if (!username || !password) {
    throw new Error('登录凭证未配置');
  }

  const br  = await chromium.launch({ executablePath: C, headless: true, args: ['--no-sandbox', '--disable-setuid-sandbox'] });
  const pg  = await (await br.newContext()).newPage();
  let tok   = null;
  pg.on('response', async r => {
    try { const d = JSON.parse(await r.text()); if (d.data?.token) tok = d.data.token; } catch (e) {}
  });
  await pg.goto(loginUrl, { waitUntil: 'networkidle' });
  await pg.waitForTimeout(2000);
  const inp = await pg.$$('input');
  await inp[0].fill(username);
  await inp[1].fill(password);
  const btnText = site.loginButtonText || '登录';
  for (const b of await pg.$$('button')) {
    if ((await b.textContent()).includes(btnText)) { await b.click(); break; }
  }
  await pg.waitForTimeout(3000);
  await br.close();
  return tok;
}

// ── 拉取单游戏明细（使用 https 模块，去掉 execSync curl） ─
async function fetchGameTransactions(apiBase, gameId, startDate, endDate, tok) {
  const base = process.env.SITE_API_BASE || apiBase;
  const rows = [];
  let page   = 1;
  while (true) {
    const data = await httpsGet(
      `${base}/api/admin/developers/transactions?page=${page}&per_page=200&game_id=${gameId}`,
      { headers: { Authorization: `Bearer ${tok}` } }
    );
    if (data.code !== 200 || !data.data?.data?.item?.length) break;
    rows.push(...data.data.data.item);
    if (page >= (data.data.last_page || 1)) break;
    page++;
  }
  return rows.filter(item => {
    const d = toCST(item.created_at).slice(0, 10);
    return d >= startDate && d <= endDate;
  });
}

// ── 佣金覆盖计算 ──────────────────────────────────────────
function applyOverride(gameName, income, origComm, origRatioStr) {
  if (OVERRIDES[gameName] !== undefined) {
    const ratio      = OVERRIDES[gameName];
    const commission = parseFloat((income * ratio).toFixed(2));
    return { commission, ratio: (ratio * 100).toFixed(0) + '%', overridden: true };
  }
  return { commission: origComm, ratio: origRatioStr, overridden: false };
}

// ── 生成 Excel ────────────────────────────────────────────
function generateVendorExcel(vendorData, outputPath) {
  const xlsx = loadXlsx();
  if (!xlsx) {
    const csvPath = outputPath.replace('.xlsx', '.csv');
    const lines   = ['游戏名称,佣金（CNY）,佣金（USDT）'];
    for (const g of vendorData.gameSummary) {
      lines.push(`${g.gameName},${g.commission},${g.commissionUsdt}`);
    }
    lines.push(`总计,${vendorData.totalCommission},${vendorData.totalCommissionUsdt}`);
    fs.writeFileSync(csvPath, lines.join('\n'), 'utf-8');
    console.log('⚠️  xlsx 未安装，已降级生成 CSV:', csvPath);
    return csvPath;
  }

  const wb = xlsx.utils.book_new();

  // 汇总 Sheet
  const summaryRows = [
    ['游戏名称', '佣金（CNY）', '佣金（USDT）'],
    ...vendorData.gameSummary.map(g => [g.gameName, g.commission, g.commissionUsdt]),
    ['总计', vendorData.totalCommission, vendorData.totalCommissionUsdt],
  ];
  xlsx.utils.book_append_sheet(wb, xlsx.utils.aoa_to_sheet(summaryRows), '汇总');

  // 各游戏明细 Sheet
  const headers = ['ID', '游戏信息', '游戏ID', '流水号', '关联订单', '玩家订单金额', '佣金比例', '佣金', '是否覆盖比例', '交易时间'];
  for (const g of vendorData.gameResults) {
    const sheetData = [headers, ...g.rows];
    xlsx.utils.book_append_sheet(wb, xlsx.utils.aoa_to_sheet(sheetData), fmtSheetName(g.gameName));
  }

  xlsx.writeFile(wb, outputPath);
  return outputPath;
}

// ── 主流程 ────────────────────────────────────────────────
async function main() {
  const argv        = process.argv.slice(2);
  const isReport    = argv.includes('--report');
  const vendorIdx   = argv.indexOf('--vendor');
  const targetVendor = vendorIdx >= 0 ? argv[vendorIdx + 1] : null;

  // 验证 --vendor 参数（仅允许字母数字中文下划线短横线）
  if (targetVendor && !/^[\w\u4e00-\u9fa5-]+$/.test(targetVendor)) {
    throw new Error('--vendor 参数格式非法: ' + targetVendor);
  }

  const now     = new Date();
  const yearIdx = argv.indexOf('--year');
  const monthIdx = argv.indexOf('--month');
  let year    = yearIdx  >= 0 ? parseInt(argv[yearIdx  + 1]) : now.getFullYear();
  let month   = monthIdx >= 0 ? parseInt(argv[monthIdx + 1]) : now.getMonth() + 1;

  // 验证年月参数范围
  if (isNaN(year) || year < 2020 || year > 2100) {
    throw new Error('--year 参数非法，必须在 2020-2100 之间: ' + year);
  }
  if (isNaN(month) || month < 1 || month > 12) {
    throw new Error('--month 参数非法，必须在 1-12 之间: ' + month);
  }

  // 1日自动补跑上月
  if (yearIdx < 0 && monthIdx < 0 && now.getDate() === 1) {
    const last = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    year  = last.getFullYear();
    month = last.getMonth() + 1;
    console.log('检测到1日，自动切换为上月补跑模式');
  }

  const startDate  = `${year}-${String(month).padStart(2, '0')}-01`;
  const endDate    = `${year}-${String(month).padStart(2, '0')}-${new Date(year, month, 0).getDate()}`;
  const monthLabel = `${year}年${month}月`;

  console.log(`\n=== 厂商佣金采集 ${monthLabel} ===`);
  console.log(`数据范围：${startDate} ~ ${endDate}\n`);

  const usdtRate   = await getUsdtRate();
  const reportData = { monthLabel, year, month, usdtRate, vendors: [] };

  for (const site of cfg.sites) {
    if (!site.enabled) continue;
    console.log(`\n====== 站点：${site.name} ======`);

    const tok = await loginGetToken(site);
    if (!tok) { console.error(`  ${site.name} 登录失败，跳过`); continue; }
    console.log('  登录成功\n');

    for (const vendor of site.vendors) {
      if (targetVendor && vendor.name !== targetVendor && vendor.id !== targetVendor) continue;
      console.log(`>>> 厂商：${vendor.name}`);

      let totalCommission = 0;
      const gameResults   = [];
      const gameSummary   = [];

      for (const game of vendor.games) {
        process.stdout.write(`    ${game.name} (ID:${game.id})... `);
        const items = await fetchGameTransactions(site.apiBase, game.id, startDate, endDate, tok);
        console.log(`${items.length} 条`);
        if (!items.length) continue;

        let gameCommission = 0;
        const rows = items.map(item => {
          const income    = parseFloat(item.income || 0);
          const origComm  = parseFloat(item.amount || 0);
          const origRatio = (item.display_commission_ratio || '0') + '%';
          const { commission, ratio, overridden } = applyOverride(game.name, income, origComm, origRatio);
          if (item.type === 1) gameCommission += commission;
          return [
            item.id,
            item.game?.name || game.name,
            item.game_id,
            item.transaction_id || '',
            item.business_id   || '',
            income.toFixed(2),
            ratio,
            commission.toFixed(2),
            overridden ? '是（已覆盖）' : '否',
            toCST(item.created_at),
          ];
        });

        gameResults.push({ gameName: game.name, rows, commission: gameCommission });
        gameSummary.push({
          gameName:       game.name,
          commission:     parseFloat(gameCommission.toFixed(2)),
          commissionUsdt: parseFloat((gameCommission / usdtRate).toFixed(2)),
        });
        totalCommission += gameCommission;
      }

      const totalUsdt = parseFloat((totalCommission / usdtRate).toFixed(2));
      console.log(`    总佣金（CNY）：${totalCommission.toFixed(2)}`);
      console.log(`    总佣金（USDT）：${totalUsdt.toFixed(2)}（汇率 ${usdtRate} CNY/USDT）\n`);

      reportData.vendors.push({
        vendorName:          vendor.name,
        totalCommission:     parseFloat(totalCommission.toFixed(2)),
        totalCommissionUsdt: totalUsdt,
        gameSummary,
        gameResults,
      });
    }
  }

  // 保存 JSON 快照
  fs.writeFileSync('/tmp/commission-report.json', JSON.stringify(reportData, null, 2));
  console.log('📄 报告数据已写入 /tmp/commission-report.json');

  // ── 生成 Excel + 发送到 TG ────────────────────────────
  if (isReport) {
    console.log('\n========== 开始发送到 Telegram ==========');
    for (const v of reportData.vendors) {
      const safeName  = v.vendorName.replace(/[^\w\u4e00-\u9fa5]/g, '_');
      const excelPath = `/tmp/佣金报告_${year}年${month}月_${safeName}.xlsx`;
      const finalPath = generateVendorExcel(v, excelPath);

      const summary = `{${v.vendorName}}：人民币 ${v.totalCommission.toFixed(2)}元，折合${v.totalCommissionUsdt.toFixed(2)}USDT`;

      console.log(`\n发送 ${v.vendorName}...`);
      await tgSendText(summary);
      tgSendDocument(finalPath);
      console.log(`VENDOR_EXCEL|${v.vendorName}|${summary}|${finalPath}`);
    }

    const allLines = reportData.vendors
      .map(v => `• {${v.vendorName}}：人民币 ${v.totalCommission.toFixed(2)}元，折合${v.totalCommissionUsdt.toFixed(2)}USDT`)
      .join('\n');
    console.log(`SUMMARY_ALL|${monthLabel}厂商数据：\n${allLines}`);
    console.log('==========================================');
  }

  console.log('\n=== 完成 ===');
}

main().catch(e => { console.error('错误:', e.message); process.exit(1); });

