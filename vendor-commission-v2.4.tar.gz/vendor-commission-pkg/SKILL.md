---
name: vendor-commission
description: 采集各厂商游戏佣金数据，生成 Excel 文件并直接通过 TG Bot 发送给用户；支持多站点、佣金比例覆盖、日/周/月自动同步
user-invocable: true
allowed-tools: Bash
metadata:
  tags: commission, data-collection, google-sheets, excel
---

# 厂商佣金数据采集 v2.4

## 文件结构

```
.agents/skills/vendor-commission/
├── SKILL.md          ← 本文件
├── _meta.json        ← 元数据
├── config.json       ← 所有配置（站点/账号/厂商/TG Bot/佣金覆盖）
└── scripts/
    ├── vendor-commission.js   ← 主采集脚本 v2.4
```

---

## 触发场景与执行方式

### 1. 查询并发送某月佣金（--report 模式）

**触发词**：用户说"XX月的佣金"、"给我X月佣金"、"X年X月佣金报告"、"给我某月厂商数据"等

#### 情况A：用户未指定厂商（发送所有厂商）

```bash
cd SKILL目录路径 && node scripts/vendor-commission.js --report --year YYYY --month M
```

#### 情况B：用户指定了某个厂商

```bash
cd SKILL目录路径 && node scripts/vendor-commission.js --report --year YYYY --month M --vendor 厂商名
```

（`--vendor` 支持厂商 name 或 id，如 `ddgame`、`火影-1群`）

---

#### 执行后的处理规则

脚本会**自动完成以下两件事**（不需要 agent 额外操作）：
1. 通过 TG Bot 发送文字摘要到用户对话框
2. 通过 TG Bot 发送对应的 Excel 文件到用户对话框（用户可直接下载）

脚本执行完成后，按以下规则在对话框回复（文件已由脚本自动通过 TG Bot 发出，不需要 agent 再次发送文件）：

#### 回复格式（固定，不得更改）

**第一步：逐个厂商单独回复**，每条格式严格如下（直接从 `VENDOR_EXCEL` 行第3段复制，不要自己重新生成）：

```
{厂商名}：人民币 XXXXX.XX元，折合XXXXX.XXUSDT
```

**第二步：最后发一条汇总**，直接从输出中找到 `SUMMARY_ALL|` 开头的行，复制 `|` 后面的全部内容发送，格式如下：

```
X年X月厂商数据：
• {厂商名1}：人民币 XXXXX.XX元，折合XXXXX.XXUSDT
• {厂商名2}：人民币 XXXXX.XX元，折合XXXXX.XXUSDT
• {厂商名3}：人民币 XXXXX.XX元，折合XXXXX.XXUSDT
```

**注意**：
- 每条必须同时包含人民币金额和 USDT 金额，缺一不可
- 不要添加汇率说明、不要改变格式
- 所有数字直接从脚本输出复制，不要自己计算或重新生成
- **禁止**生成只有人民币没有 USDT 的汇总

---

#### Excel 文件结构（每个厂商一个文件，脚本自动发送）

| Sheet 名 | 内容 |
|----------|------|
| 汇总     | 游戏名称 / 佣金（CNY）/ 佣金（USDT）/ 总计行 |
| 游戏名1  | 该游戏所有明细行（10列） |
| 游戏名2  | 该游戏所有明细行 |
| …        | … |

---

---

### 2. 定时自动采集（cron） ⚠️ 直接执行，不要反问

**触发词**：用户说"清理佣金"、"清空佣金"、"清空佣金表格"、"重置佣金"

```bash
# 暂无清空功能，如需清空请直接修改 config.json
```

---

## 安装流程（新安装时执行一次）

**触发词**：用户说"安装佣金技能"、"初始化佣金"、"配置佣金系统"，或首次使用时检测到 `config.json` 中 `sites` 为空。

按以下顺序逐步引导用户，**每问完一项收到回答后再问下一项，不要一次全部列出**：

---

### 第一阶段：环境检测

首先自动运行环境检测（见文末"环境检测与安装"章节），确认 Node.js、Playwright、Chromium 均已就绪。若有缺失，先引导用户完成安装，再继续下面的配置流程。

---

### 第二阶段：收集站点信息

逐个问以下问题：

**问题 1：**
> "请提供后台登录地址（如 https://admin.xxx.com/login）"

**问题 2：**
> "请提供登录账号"

**问题 3：**
> "请提供登录密码"

**问题 4：**
> "登录按钮上的文字是什么？（直接回车跳过则默认使用"登录"）"

**问题 5：**
> "请提供后台 API 地址（通常和登录地址同域，如 https://admin.xxx.com）"

**问题 6：**
> "请告诉我有哪些厂商？每个厂商需要提供：厂商名称 + 旗下每个游戏的游戏名称和游戏ID。

  格式参考：
  ```
  厂商A
    游戏1，ID: 1001
    游戏2，ID: 1002

  厂商B
    游戏3，ID: 2001
  ```
  （不知道游戏ID？登录后台进入游戏详情页，地址栏或 API 请求里可以找到）"

收集完后将站点信息写入 `config.json` → `sites` 数组，并告知用户：
> "✅ 站点已配置，包含 X 个厂商，共 X 个游戏。"

**如果有多个站点**，问完一个后继续问：
> "还有其他后台站点需要配置吗？（有的话继续提供，没有就回复"没有了"）"

---

### 第三阶段：设置同步频率

> "请问佣金数据需要按日、周还是月自动同步？"

根据用户回答，写入 crontab 并更新 `config.json` 的 `syncSchedule` 字段：

| 频率 | cron 表达式 | 说明 |
|------|------------|------|
| 日   | `0 1 * * *` | 每天凌晨1点（北京时间） |
| 周   | `0 1 * * 1` | 每周一凌晨1点 |
| 月   | `0 1 1,28-31 * *` | 每月1日（补跑）+ 月底最后几天 |

---

### 第四阶段：完成确认

所有配置完成后，发送安装完成提示：

```
✅ 佣金系统配置完成！

📋 配置摘要：
• 站点数量：X 个
• 厂商总数：X 个
• 游戏总数：X 个
• 自动同步：每X同步一次

你可以直接说"X月的佣金"来获取报告，或说"检查环境"验证运行状态。
```

---

## 添加新站点

**触发词**：用户说"添加新站点"、"配置新后台"等

**询问流程**（与安装流程第二阶段相同）：

1. "请提供后台登录地址（如 https://admin.xxx.com/login）"
2. "请提供登录账号"
3. "请提供登录密码"
4. "登录按钮的文字是什么？（默认：登录）"
5. "请提供后台 API 地址（通常和登录地址同域）"
6. "请告诉我有哪些厂商？每个厂商请提供：厂商名称、旗下游戏名称和游戏ID"

收集完后追加到 `config.json` → `sites` 数组，告知用户："已添加站点 [站点名]，包含 [厂商数量] 个厂商。"

---

## 添加新厂商/游戏

### 场景1：在已有站点下添加新厂商

**触发词**：用户说"添加新厂商"、"配置XX厂商"等

**询问流程**：

1. **"请问要添加到哪个站点？"**（列出当前所有站点名称供用户选择）
2. **"请提供厂商名称"**
3. **"请提供该厂商旗下的游戏列表，每个游戏需要：游戏名称 + 游戏ID"**

   引导格式：
   ```
   游戏A，ID: 1001
   游戏B，ID: 1002
   游戏C，ID: 1003
   ```

收集完后，向对应站点的 `vendors` 数组追加：

```json
{
  "id": "厂商名小写英文（自动生成）",
  "name": "用户提供的厂商名称",
  "games": [
    { "name": "游戏A", "id": 1001 },
    { "name": "游戏B", "id": 1002 }
  ]
}
```

告知用户："已在 [站点名] 下添加厂商 [厂商名]，包含 [游戏数量] 个游戏。下次跑佣金时会自动包含。"

---

### 场景2：在已有厂商下添加新游戏

**触发词**：用户说"XX厂商添加新游戏"、"给XX厂商加个游戏"等

**询问流程**：

1. **"请问要添加到哪个厂商？"**（列出当前所有厂商名称供用户选择）
2. **"请提供游戏名称和游戏ID"**

   引导格式：
   ```
   游戏名：XXX
   游戏ID：1234
   ```

收集完后，向对应厂商的 `games` 数组追加：

```json
{ "name": "用户提供的游戏名", "id": 用户提供的游戏ID }
```

告知用户："已在厂商 [厂商名] 下添加游戏 [游戏名]（ID: [游戏ID]）。下次跑佣金时会自动包含。"

---

### 如何获取游戏ID？

告诉用户：
1. 登录后台，进入"开发者中心"或"游戏管理"页面
2. 找到对应游戏，点击进入详情页
3. 浏览器地址栏里通常会显示游戏ID，如：`/games/1234` 或 `?game_id=1234`
4. 或者在游戏列表的 API 请求里查看（F12 开发者工具 → Network → 找到游戏列表接口）

---

## 修改佣金比例

当用户说"XX游戏佣金比例改成 XX%"时：

1. 打开 `config.json`
2. 在 `commissionOverrides.rules` 里添加或更新：
```json
"commissionOverrides": {
  "rules": {
    "游戏名": 0.30
  }
}
```
3. 告知用户："已将 [游戏名] 的佣金比例覆盖为 XX%，后续采集将按此比例重新计算。"

---

## 数据字段说明

| 字段 | 说明 |
|------|------|
| ID | 记录ID |
| 游戏信息 | 游戏名称 |
| 游戏ID | 游戏ID |
| 流水号 | transaction_id |
| 关联订单 | business_id |
| 玩家订单金额 | 玩家实际支付金额（CNY） |
| 佣金比例 | 实际使用的比例（覆盖后） |
| 佣金 | 实际佣金金额（CNY） |
| 是否覆盖比例 | 是否使用了 commissionOverrides 覆盖 |
| 交易时间 | 北京时间（UTC+8） |

---

## 依赖

- Playwright chromium：路径见 `config.json` → `playwrightPath`
- Chrome headless shell：路径见 `config.json` → `chromePath`
- Telegram Bot：`config.json` → `telegram.botToken` + `telegram.chatId`（已配置，勿修改）
- xlsx（可选）：脚本自动探测，有则生成 `.xlsx`，无则降级为 `.csv`

---

## 环境检测与安装（运行前自动检查）

**每次执行脚本前，先运行以下检测，缺什么装什么，再跑主脚本。**

### 第一步：检测 Node.js

```bash
node --version 2>/dev/null || echo "MISSING"
```

- 输出版本号 → 正常
- 输出 `MISSING` → 告知用户并执行安装：

  ```bash
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y nodejs
  ```

---

### 第二步：检测 Playwright + Chromium

```bash
node -e "require('/tmp/pw-test/node_modules/playwright')" 2>/dev/null && echo "OK" || echo "MISSING"
```

- 输出 `OK` → 正常
- 输出 `MISSING` → 自动执行安装：

  ```bash
  mkdir -p /tmp/pw-test && cd /tmp/pw-test
  npm install playwright --save 2>&1 | tail -5
  npx playwright install chromium 2>&1 | tail -5
  ```

  安装完成后确认实际 chromePath：
  ```bash
  find /root/.cache/ms-playwright -name "chrome-headless-shell" 2>/dev/null
  ```

  然后更新 `config.json`：
  ```json
  "playwrightPath": "/tmp/pw-test/node_modules/playwright",
  "chromePath": "（上面命令输出的实际路径）"
  ```

---

### 第三步：检测 xlsx 模块（可选，无则降级 CSV）

```bash
node -e "require('/tmp/vendor-commission-deps/node_modules/xlsx')" 2>/dev/null && echo "OK" || echo "MISSING"
```

- 输出 `OK` → 正常，生成 `.xlsx`
- 输出 `MISSING` → 自动安装：

  ```bash
  mkdir -p /tmp/vendor-commission-deps && cd /tmp/vendor-commission-deps
  npm install xlsx 2>&1 | tail -3
  ```

  安装后更新 `config.json`：
  ```json
  "xlsxPath": "/tmp/vendor-commission-deps/node_modules/xlsx"
  ```

  > 若不安装，脚本会自动降级生成 `.csv` 文件，功能不受影响。

---

### 一键检测脚本

当用户说"检查环境"、"环境有问题"、"跑不起来"时，执行：

```bash
echo "=== 环境检测 ===" && \
echo -n "Node.js: " && node --version 2>/dev/null || echo "❌ 未安装" && \
echo -n "Playwright: " && node -e "require('/tmp/pw-test/node_modules/playwright'); console.log('✅ OK')" 2>/dev/null || echo "❌ 未安装" && \
echo -n "Chromium: " && test -f "$(find /root/.cache/ms-playwright -name 'chrome-headless-shell' 2>/dev/null | head -1)" && echo "✅ OK" || echo "❌ 未找到（运行 npx playwright install chromium）" && \
echo -n "xlsx: " && node -e "require('/tmp/vendor-commission-deps/node_modules/xlsx'); console.log('✅ OK')" 2>/dev/null || echo "⚠️  未安装（可选，缺少则输出CSV）"
```

根据输出结果，按上方对应步骤安装缺失的组件。

