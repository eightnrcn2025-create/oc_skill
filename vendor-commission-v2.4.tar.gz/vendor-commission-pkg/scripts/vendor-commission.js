// vendor-commission.js v2.4
// 厂商佣金数据采集 — 从 config.json 读取配置，生成 Excel 并通过 TG Bot 发送
// 用法：
//   node vendor-commission.js                        # 自动判断当月/补跑
//   node vendor-commission.js --year 2026 --month 3  # 指定年月
//   node vendor-commission.js --report               # 生成 Excel 发送到 TG（按月查询时使用）
//   node vendor-commission.js --report --vendor ddgame  # 只处理指定厂商

'use strict';
const path   = require('path');
const fs     = require('fs');
const { execSync } = require('child_process');

// ── 读取配置 ──────────────────────────────────────────────
const CONFIG_PATH = path.join(__dirname, '..', 'config.json');
const cfg = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf-8'));

const { chromium } = require(cfg.playwrightPath);
const C            = cfg.chromePath;
const FALLBACK_RATE = cfg.usdtFallbackRate || 7.2;
const OVERRIDES    = cfg.commissionOverrides?.rules || {};
const TG_TOKEN     = cfg.telegram?.botToken || '';
const TG_CHATID    = cfg.telegram?.chatId   || '';

// 汇率本地缓存文件（上次成功获取的汇率，作为最终兜底）
const RATE_CACHE_FILE = path.join(__dirname, '..', 'rate_cache.json');

// ── xlsx 模块自动探测 ─────────────────────────────────────
function loadXlsx() {
  const candidates = [
    cfg.xlsxPath,
    '/tmp/vendor-commission-deps/node_modules/xlsx',
    '/tmp/pw-test/node_modules/xlsx',
    '/tmp/gp-recon2/node_modules/xlsx',
  ].filter(Boolean);
  for (const p of candidates) {
    try { return require(p); } catch (e) {}
  }
  return null;
}

// ── 工具函数 ──────────────────────────────────────────────
function fmtSheetName(n) {
  return n.replace(/[\\\/\?\*\[\]:]/g, '').slice(0, 31);
}

function toCST(utcStr) {
  if (!utcStr) return '';
  const d   = new Date(utcStr);
  const cst = new Date(d.getTime() + 8 * 3600 * 1000);
  return cst.toISOString().replace('T', ' ').slice(0, 19);
}

// ── 汇率本地缓存读写 ──────────────────────────────────────
function loadCachedRate() {
  try {
    if (fs.existsSync(RATE_CACHE_FILE)) {
      const c = JSON.parse(fs.readFileSync(RATE_CACHE_FILE, 'utf-8'));
      if (c.rate > 0) return c.rate;
    }
  } catch (e) {}
  return null;
}

function saveCachedRate(rate) {
  try {
    fs.writeFileSync(RATE_CACHE_FILE, JSON.stringify({
      rate,
      updatedAt: new Date().toISOString(),
    }), 'utf-8');
  } catch (e) {}
}

// ── 实时汇率：5个接口依次尝试，全失败用本地缓存，再失败用配置兜底 ──
function getUsdtRate() {
  // 接口1：Binance P2P（卖单中位数，最贴近实际交易价）
  try {
    const cmd = `curl -s --max-time 10 "https://p2p.binance.com/bapi/c2c/v2/friendly/c2c/adv/search" \
      -H "Content-Type: application/json" \
      -d '{"asset":"USDT","fiat":"CNY","merchantCheck":false,"page":1,"payTypes":[],"publisherType":null,"rows":5,"tradeType":"SELL"}' \
      -A "Mozilla/5.0" 2>/dev/null`;
    const data = JSON.parse(execSync(cmd, { encoding: 'utf-8' }))?.data || [];
    const prices = data.map(x => parseFloat(x?.adv?.price)).filter(x => x > 0).sort((a, b) => a - b);
    if (prices.length) {
      const mid = prices[Math.floor(prices.length / 2)];
      console.log('实时汇率（Binance P2P）1 USDT =', mid, 'CNY');
      saveCachedRate(mid);
      return mid;
    }
  } catch (e) {}

  // 接口2：OKX C2C（法币买单价）
  try {
    const res = execSync(
      'curl -s --max-time 10 "https://www.okx.com/v3/c2c/otc-ticker/quotedPrice?side=buy&quoteCurrency=CNY&baseCurrency=USDT" -A "Mozilla/5.0" 2>/dev/null',
      { encoding: 'utf-8' }
    );
    const price = parseFloat(JSON.parse(res)?.data?.[0]?.price);
    if (price > 0) {
      console.log('实时汇率（OKX C2C）1 USDT =', price, 'CNY');
      saveCachedRate(price);
      return price;
    }
  } catch (e) {}

  // 接口3：CoinGecko
  try {
    const res = execSync(
      'curl -s --max-time 10 "https://api.coingecko.com/api/v3/simple/price?ids=tether&vs_currencies=cny" -A "Mozilla/5.0" 2>/dev/null',
      { encoding: 'utf-8' }
    );
    const price = parseFloat(JSON.parse(res)?.tether?.cny);
    if (price > 0) {
      console.log('实时汇率（CoinGecko）1 USDT =', price, 'CNY');
      saveCachedRate(price);
      return price;
    }
  } catch (e) {}

  // 接口4：fawazahmed0 Currency API（CDN 镜像，无需 key）
  try {
    const res = execSync(
      'curl -s --max-time 10 "https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usdt.json" 2>/dev/null',
      { encoding: 'utf-8' }
    );
    const price = parseFloat(JSON.parse(res)?.usdt?.cny);
    if (price > 0) {
      console.log('实时汇率（fawazahmed0）1 USDT =', price, 'CNY');
      saveCachedRate(price);
      return price;
    }
  } catch (e) {}

  // 接口5：ExchangeRate-API（CNY→USD 反推）
  try {
    const res = execSync(
      'curl -s --max-time 10 "https://open.er-api.com/v6/latest/CNY" -A "Mozilla/5.0" 2>/dev/null',
      { encoding: 'utf-8' }
    );
    const usdPerCny = parseFloat(JSON.parse(res)?.rates?.USD);
    if (usdPerCny > 0) {
      const price = parseFloat((1 / usdPerCny).toFixed(4));
      console.log('实时汇率（ExchangeRate-API）1 USDT =', price, 'CNY');
      saveCachedRate(price);
      return price;
    }
  } catch (e) {}

  // 兜底1：上次成功缓存的汇率
  const cached = loadCachedRate();
  if (cached) {
    console.warn(`⚠️  所有实时接口均失败，使用上次缓存汇率 1 USDT = ${cached} CNY`);
    return cached;
  }

  // 兜底2：config.json 中的固定值
  console.warn(`⚠️  所有接口及缓存均失败，使用配置兜底值 1 USDT = ${FALLBACK_RATE} CNY`);
  return FALLBACK_RATE;
}

// ── Telegram 发送 ─────────────────────────────────────────
function tgSendText(text) {
  if (!TG_TOKEN || !TG_CHATID) { console.log('[TG] 未配置 botToken/chatId，跳过'); return; }
  try {
    const tmp = '/tmp/tg-text.json';
    fs.writeFileSync(tmp, JSON.stringify({ chat_id: TG_CHATID, text }));
    const r = JSON.parse(execSync(`curl -s -X POST "https://api.telegram.org/bot${TG_TOKEN}/sendMessage" -H "Content-Type: application/json" -d @${tmp}`, { encoding: 'utf-8' }));
    console.log(r.ok ? '[TG] 文字发送成功' : '[TG] 文字发送失败: ' + r.description);
  } catch (e) { console.error('[TG] 文字发送异常:', e.message); }
}

function tgSendDocument(filePath) {
  if (!TG_TOKEN || !TG_CHATID) { console.log('[TG] 未配置 botToken/chatId，跳过'); return; }
  if (!fs.existsSync(filePath)) { console.error('[TG] 文件不存在:', filePath); return; }
  try {
    const r = JSON.parse(execSync(
      `curl -s -X POST "https://api.telegram.org/bot${TG_TOKEN}/sendDocument" -F "chat_id=${TG_CHATID}" -F "document=@${filePath}"`,
      { encoding: 'utf-8' }
    ));
    console.log(r.ok ? '[TG] 文件发送成功: ' + path.basename(filePath) : '[TG] 文件发送失败: ' + r.description);
  } catch (e) { console.error('[TG] 文件发送异常:', e.message); }
}

// ── 登录（网页模拟） ──────────────────────────────────────
async function loginGetToken(site) {
  const br  = await chromium.launch({ executablePath: C, headless: true, args: ['--no-sandbox', '--disable-setuid-sandbox'] });
  const pg  = await (await br.newContext()).newPage();
  let tok   = null;
  pg.on('response', async r => {
    try { const d = JSON.parse(await r.text()); if (d.data?.token) tok = d.data.token; } catch (e) {}
  });
  await pg.goto(site.loginUrl, { waitUntil: 'networkidle' });
  await pg.waitForTimeout(2000);
  const inp = await pg.$$('input');
  await inp[0].fill(site.username);
  await inp[1].fill(site.password);
  const btnText = site.loginButtonText || '登录';
  for (const b of await pg.$$('button')) {
    if ((await b.textContent()).includes(btnText)) { await b.click(); break; }
  }
  await pg.waitForTimeout(3000);
  await br.close();
  return tok;
}

// ── 拉取单游戏明细（翻页 + 按北京时间过滤） ──────────────
function fetchGameTransactions(apiBase, gameId, startDate, endDate, tok) {
  const rows = [];
  let page   = 1;
  while (true) {
    const res = JSON.parse(execSync(
      `curl -s "${apiBase}/api/admin/developers/transactions?page=${page}&per_page=200&game_id=${gameId}" -H "Authorization: Bearer ${tok}" -A "Mozilla/5.0" 2>/dev/null`,
      { encoding: 'utf-8' }
    ));
    if (res.code !== 200 || !res.data?.data?.item?.length) break;
    rows.push(...res.data.data.item);
    if (page >= (res.data.last_page || 1)) break;
    page++;
  }
  return rows.filter(item => {
    const d = toCST(item.created_at).slice(0, 10);
    return d >= startDate && d <= endDate;
  });
}

// ── 佣金比例覆盖 ──────────────────────────────────────────
function applyOverride(gameName, income, origComm, origRatio) {
  if (OVERRIDES[gameName] !== undefined) {
    const ratio = parseFloat(OVERRIDES[gameName]);
    return { commission: parseFloat((income * ratio).toFixed(2)), ratio: (ratio * 100).toFixed(2) + '%', overridden: true };
  }
  return { commission: origComm, ratio: origRatio, overridden: false };
}

// ── 生成单厂商 Excel ──────────────────────────────────────
// Sheet1 = 汇总，后续每个游戏一个明细 sheet
// 返回实际写入路径（.xlsx 或降级 .csv）
function generateVendorExcel(vendorData, outputPath) {
  const DETAIL_HEADERS = ['ID', '游戏信息', '游戏ID', '流水号', '关联订单', '玩家订单金额', '佣金比例', '佣金', '是否覆盖比例', '交易时间'];
  const xlsxMod = loadXlsx();

  if (xlsxMod) {
    const wb = xlsxMod.utils.book_new();

    // 汇总 sheet
    const summaryRows = [
      ['游戏名称', '佣金（CNY）', '佣金（USDT）'],
      ...vendorData.gameSummary.map(g => [g.gameName, g.commission.toFixed(2), g.commissionUsdt.toFixed(2)]),
      ['总计', vendorData.totalCommission.toFixed(2), vendorData.totalCommissionUsdt.toFixed(2)],
    ];
    xlsxMod.utils.book_append_sheet(wb, xlsxMod.utils.aoa_to_sheet(summaryRows), '汇总');

    // 每个游戏明细 sheet
    for (const game of vendorData.gameResults) {
      if (!game.rows?.length) continue;
      xlsxMod.utils.book_append_sheet(wb, xlsxMod.utils.aoa_to_sheet([DETAIL_HEADERS, ...game.rows]), fmtSheetName(game.gameName));
    }

    xlsxMod.writeFile(wb, outputPath);
    return outputPath;
  }

  // 降级：CSV 汇总
  const csvPath = outputPath.replace(/\.xlsx$/, '.csv');
  const lines = ['游戏名称,佣金（CNY）,佣金（USDT）',
    ...vendorData.gameSummary.map(g => `${g.gameName},${g.commission.toFixed(2)},${g.commissionUsdt.toFixed(2)}`),
    `总计,${vendorData.totalCommission.toFixed(2)},${vendorData.totalCommissionUsdt.toFixed(2)}`,
  ];
  fs.writeFileSync(csvPath, '\uFEFF' + lines.join('\n'), 'utf-8');
  return csvPath;
}

// ── 主逻辑 ────────────────────────────────────────────────
async function main() {
  const argv         = process.argv.slice(2);
  const isReport     = argv.includes('--report');
  const vendorIdx    = argv.indexOf('--vendor');
  const targetVendor = vendorIdx >= 0 ? argv[vendorIdx + 1] : null;
  const yearIdx      = argv.indexOf('--year');
  const monthIdx     = argv.indexOf('--month');

  const now   = new Date(Date.now() + 8 * 3600 * 1000);
  let year    = yearIdx  >= 0 ? parseInt(argv[yearIdx  + 1]) : now.getFullYear();
  let month   = monthIdx >= 0 ? parseInt(argv[monthIdx + 1]) : now.getMonth() + 1;

  // 1日自动补跑上月
  if (yearIdx < 0 && monthIdx < 0 && now.getDate() === 1) {
    const last = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    year  = last.getFullYear();
    month = last.getMonth() + 1;
    console.log('检测到1日，自动切换为上月补跑模式');
  }

  const startDate  = `${year}-${String(month).padStart(2, '0')}-01`;
  const endDate    = `${year}-${String(month).padStart(2, '0')}-${new Date(year, month, 0).getDate()}`;
  const monthLabel = `${year}年${month}月`;

  console.log(`\n=== 厂商佣金采集 ${monthLabel} ===`);
  console.log(`数据范围：${startDate} ~ ${endDate}\n`);

  const usdtRate   = getUsdtRate();
  const reportData = { monthLabel, year, month, usdtRate, vendors: [] };

  for (const site of cfg.sites) {
    if (!site.enabled) continue;
    console.log(`\n====== 站点：${site.name} ======`);

    const tok = await loginGetToken(site);
    if (!tok) { console.error(`  ${site.name} 登录失败，跳过`); continue; }
    console.log('  登录成功\n');

    for (const vendor of site.vendors) {
      if (targetVendor && vendor.name !== targetVendor && vendor.id !== targetVendor) continue;
      console.log(`>>> 厂商：${vendor.name}`);

      let totalCommission = 0;
      const gameResults   = [];
      const gameSummary   = [];

      for (const game of vendor.games) {
        process.stdout.write(`    ${game.name} (ID:${game.id})... `);
        const items = fetchGameTransactions(site.apiBase, game.id, startDate, endDate, tok);
        console.log(`${items.length} 条`);
        if (!items.length) continue;

        let gameCommission = 0;
        const rows = items.map(item => {
          const income    = parseFloat(item.income || 0);
          const origComm  = parseFloat(item.amount || 0);
          const origRatio = (item.display_commission_ratio || '0') + '%';
          const { commission, ratio, overridden } = applyOverride(game.name, income, origComm, origRatio);
          if (item.type === 1) gameCommission += commission;
          return [
            item.id,
            item.game?.name || game.name,
            item.game_id,
            item.transaction_id || '',
            item.business_id   || '',
            income.toFixed(2),
            ratio,
            commission.toFixed(2),
            overridden ? '是（已覆盖）' : '否',
            toCST(item.created_at),
          ];
        });

        gameResults.push({ gameName: game.name, rows, commission: gameCommission });
        gameSummary.push({
          gameName:       game.name,
          commission:     parseFloat(gameCommission.toFixed(2)),
          commissionUsdt: parseFloat((gameCommission / usdtRate).toFixed(2)),
        });
        totalCommission += gameCommission;
      }

      const totalUsdt = parseFloat((totalCommission / usdtRate).toFixed(2));
      console.log(`    总佣金（CNY）：${totalCommission.toFixed(2)}`);
      console.log(`    总佣金（USDT）：${totalUsdt.toFixed(2)}（汇率 ${usdtRate} CNY/USDT）\n`);

      reportData.vendors.push({
        vendorName:          vendor.name,
        totalCommission:     parseFloat(totalCommission.toFixed(2)),
        totalCommissionUsdt: totalUsdt,
        gameSummary,
        gameResults,
      });
    }
  }

  // 保存 JSON 快照
  fs.writeFileSync('/tmp/commission-report.json', JSON.stringify(reportData, null, 2));
  console.log('📄 报告数据已写入 /tmp/commission-report.json');

  // ── 生成 Excel + 发送到 TG ────────────────────────────
  if (isReport) {
    console.log('\n========== 开始发送到 Telegram ==========');
    for (const v of reportData.vendors) {
      const safeName  = v.vendorName.replace(/[^\w\u4e00-\u9fa5]/g, '_');
      const excelPath = `/tmp/佣金报告_${year}年${month}月_${safeName}.xlsx`;
      const finalPath = generateVendorExcel(v, excelPath);

      // 格式固定：{厂商名}：人民币 XXXXX.XX元，折合XXXXX.XXUSDT
      const summary = `{${v.vendorName}}：人民币 ${v.totalCommission.toFixed(2)}元，折合${v.totalCommissionUsdt.toFixed(2)}USDT`;

      console.log(`\n发送 ${v.vendorName}...`);
      tgSendText(summary);
      tgSendDocument(finalPath);
      console.log(`VENDOR_EXCEL|${v.vendorName}|${summary}|${finalPath}`);
    }

    // 汇总行（供 agent 回复用户）
    const allLines = reportData.vendors
      .map(v => `• {${v.vendorName}}：人民币 ${v.totalCommission.toFixed(2)}元，折合${v.totalCommissionUsdt.toFixed(2)}USDT`)
      .join('\n');
    console.log(`SUMMARY_ALL|${monthLabel}厂商数据：\n${allLines}`);
    console.log('==========================================');
  }

  console.log('\n=== 完成 ===');
}

main().catch(e => { console.error('错误:', e.message); process.exit(1); });

