---
name: vendor-commission
description: 采集各厂商游戏佣金数据，写入 Google Sheets，生成 Excel 文件并直接通过 TG Bot 发送给用户；支持多站点、佣金比例覆盖、日/周/月自动同步
user-invocable: true
allowed-tools: Bash
metadata:
  tags: commission, data-collection, google-sheets, excel
---

# 厂商佣金数据采集 v2.2

## 文件结构

```
.agents/skills/vendor-commission/
├── SKILL.md          ← 本文件
├── _meta.json        ← 元数据
├── config.json       ← 所有配置（站点/账号/厂商/TG Bot/佣金覆盖）
└── scripts/
    ├── vendor-commission.js   ← 主采集脚本 v2.2
    └── commission-gas.js      ← Google Apps Script 端代码（部署在 GAS）
```

---

## 触发场景与执行方式

### 1. 查询并发送某月佣金（--report 模式）

**触发词**：用户说"XX月的佣金"、"给我X月佣金"、"X年X月佣金报告"、"给我某月厂商数据"等

#### 情况A：用户未指定厂商（发送所有厂商）

```bash
cd SKILL目录路径 && node scripts/vendor-commission.js --report --year YYYY --month M
```

#### 情况B：用户指定了某个厂商

```bash
cd SKILL目录路径 && node scripts/vendor-commission.js --report --year YYYY --month M --vendor 厂商名
```

（`--vendor` 支持厂商 name 或 id，如 `ddgame`、`火影-1群`）

---

#### 执行后的处理规则

脚本会**自动完成以下两件事**（不需要 agent 额外操作）：
1. 通过 TG Bot 发送文字摘要到用户对话框
2. 通过 TG Bot 发送对应的 Excel 文件到用户对话框（用户可直接下载）

脚本执行完成后，按以下规则在对话框回复（文件已由脚本自动通过 TG Bot 发出，不需要 agent 再次发送文件）：

#### 回复格式（固定，不得更改）

**第一步：逐个厂商单独回复**，每条格式严格如下（直接从 `VENDOR_EXCEL` 行第3段复制，不要自己重新生成）：

```
{厂商名}：人民币 XXXXX.XX元，折合XXXXX.XXUSDT
```

**第二步：最后发一条汇总**，直接从输出中找到 `SUMMARY_ALL|` 开头的行，复制 `|` 后面的全部内容发送，格式如下：

```
X年X月厂商数据：
• {厂商名1}：人民币 XXXXX.XX元，折合XXXXX.XXUSDT
• {厂商名2}：人民币 XXXXX.XX元，折合XXXXX.XXUSDT
• {厂商名3}：人民币 XXXXX.XX元，折合XXXXX.XXUSDT
```

**注意**：
- 每条必须同时包含人民币金额和 USDT 金额，缺一不可
- 不要添加汇率说明、不要改变格式
- 所有数字直接从脚本输出复制，不要自己计算或重新生成
- **禁止**生成只有人民币没有 USDT 的汇总

---

#### Excel 文件结构（每个厂商一个文件，脚本自动发送）

| Sheet 名 | 内容 |
|----------|------|
| 汇总     | 游戏名称 / 佣金（CNY）/ 佣金（USDT）/ 总计行 |
| 游戏名1  | 该游戏所有明细行（10列） |
| 游戏名2  | 该游戏所有明细行 |
| …        | … |

---

### 2. 正常采集并写入 Google Sheets

**触发词**：用户说"跑佣金"、"采集佣金数据"、"更新厂商表格"

```bash
cd SKILL目录路径 && node scripts/vendor-commission.js
```

指定年月：
```bash
cd SKILL目录路径 && node scripts/vendor-commission.js --year 2026 --month 3
```

---

### 3. 清理数据 ⚠️ 直接执行，不要反问

**触发词**：用户说"清理佣金"、"清空佣金"、"清空佣金表格"、"重置佣金"

```bash
cd SKILL目录路径 && node scripts/vendor-commission.js --clear
```

---

## 安装流程（新安装时执行一次）

1. 询问用户：**"请问佣金数据需要按日、周还是月自动同步？"**
2. 根据用户回答，写入 crontab 并更新 `config.json` 的 `syncSchedule` 字段：

| 频率 | cron 表达式 | 说明 |
|------|------------|------|
| 日   | `0 1 * * *` | 每天凌晨1点（北京时间） |
| 周   | `0 1 * * 1` | 每周一凌晨1点 |
| 月   | `0 1 1,28-31 * *` | 每月1日（补跑）+ 月底最后几天 |

---

## 添加新站点/厂商

当用户提供新的网站账号信息时，向 `config.json` 的 `sites` 数组追加一个新站点对象：

```json
{
  "id": "新站点唯一ID",
  "name": "站点显示名称",
  "enabled": true,
  "loginUrl": "https://xxx.com/login",
  "loginButtonText": "登录",
  "username": "账号",
  "password": "密码",
  "apiBase": "https://xxx.com",
  "gasWebAppUrl": "https://script.google.com/macros/s/xxx/exec",
  "vendors": [
    {
      "id": "厂商ID",
      "name": "厂商名称",
      "spreadsheetId": "Google Sheet ID",
      "games": [
        { "name": "游戏名", "id": 游戏ID }
      ]
    }
  ]
}
```

---

## 修改佣金比例

当用户说"XX游戏佣金比例改成 XX%"时：

1. 打开 `config.json`
2. 在 `commissionOverrides.rules` 里添加或更新：
```json
"commissionOverrides": {
  "rules": {
    "游戏名": 0.30
  }
}
```
3. 告知用户："已将 [游戏名] 的佣金比例覆盖为 XX%，后续采集将按此比例重新计算。"

---

## 数据字段说明

| 字段 | 说明 |
|------|------|
| ID | 记录ID |
| 游戏信息 | 游戏名称 |
| 游戏ID | 游戏ID |
| 流水号 | transaction_id |
| 关联订单 | business_id |
| 玩家订单金额 | 玩家实际支付金额（CNY） |
| 佣金比例 | 实际使用的比例（覆盖后） |
| 佣金 | 实际佣金金额（CNY） |
| 是否覆盖比例 | 是否使用了 commissionOverrides 覆盖 |
| 交易时间 | 北京时间（UTC+8） |

---

## 依赖

- Playwright chromium：路径见 `config.json` → `playwrightPath`
- Chrome headless shell：路径见 `config.json` → `chromePath`
- Google Apps Script WebApp：每个站点独立配置在 `gasWebAppUrl`
- Telegram Bot：`config.json` → `telegram.botToken` + `telegram.chatId`（已配置，勿修改）
- xlsx（可选）：脚本自动探测，有则生成 `.xlsx`，无则降级为 `.csv`

