// vendor-commission.js v2.2
// 厂商佣金数据采集 — 从 config.json 读取配置，支持多站点、多厂商、佣金比例覆盖
// 用法：
//   node vendor-commission.js                        # 自动判断当月/补跑
//   node vendor-commission.js --year 2026 --month 3  # 指定年月
//   node vendor-commission.js --clear                # 清空所有 sheet 数据（保留格式）
//   node vendor-commission.js --report               # 每个厂商生成独立 Excel，直接通过 TG Bot 发送给用户

'use strict';
const path   = require('path');
const fs     = require('fs');
const { execSync } = require('child_process');

// ── 读取配置 ──────────────────────────────────────────────
const CONFIG_PATH = path.join(__dirname, '..', 'config.json');
const cfg = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf-8'));

const { chromium } = require(cfg.playwrightPath);
const C = cfg.chromePath;
const FALLBACK_RATE = cfg.usdtFallbackRate || 7.2;
const OVERRIDES = cfg.commissionOverrides?.rules || {};

// ── TG 配置 ───────────────────────────────────────────────
const TG_TOKEN  = cfg.telegram?.botToken  || '';
const TG_CHATID = cfg.telegram?.chatId    || '';

// ── xlsx 模块自动探测 ─────────────────────────────────────
function loadXlsx() {
  const candidates = [
    cfg.xlsxPath,
    '/tmp/vendor-commission-deps/node_modules/xlsx',
    '/tmp/pw-test/node_modules/xlsx',
    '/tmp/gp-recon2/node_modules/xlsx',
  ].filter(Boolean);
  for (const p of candidates) {
    try { return require(p); } catch (e) {}
  }
  return null;
}

// ── 工具函数 ──────────────────────────────────────────────
function fmtSheetName(n) {
  return n.replace(/[\\\/\?\*\[\]:]/g, '').slice(0, 30);
}

function toCST(utcStr) {
  if (!utcStr) return '';
  const d = new Date(utcStr);
  const cst = new Date(d.getTime() + 8 * 3600 * 1000);
  return cst.toISOString().replace('T', ' ').slice(0, 19);
}

function getUsdtRate() {
  // 1) Binance P2P CNY 卖单中位数（优先）
  try {
    const cmd = `curl -s "https://p2p.binance.com/bapi/c2c/v2/friendly/c2c/adv/search" -H "Content-Type: application/json" -d '{"asset":"USDT","fiat":"CNY","merchantCheck":false,"page":1,"payTypes":[],"publisherType":null,"rows":5,"tradeType":"SELL"}' -A "Mozilla/5.0" 2>/dev/null`;
    const res = execSync(cmd, { encoding: 'utf-8' });
    const data = JSON.parse(res)?.data || [];
    const prices = data.map(x => parseFloat(x?.adv?.price)).filter(x => x > 0).sort((a,b)=>a-b);
    if (prices.length) {
      const mid = prices[Math.floor(prices.length/2)];
      console.log('实时汇率（Binance P2P）1 USDT =', mid, 'CNY');
      return mid;
    }
  } catch (e) {}

  // 2) CoinGecko
  try {
    const res = execSync('curl -s "https://api.coingecko.com/api/v3/simple/price?ids=tether&vs_currencies=cny" -A "Mozilla/5.0" 2>/dev/null', { encoding: 'utf-8' });
    const price = parseFloat(JSON.parse(res)?.tether?.cny);
    if (price > 0) { console.log('实时汇率（CoinGecko）1 USDT =', price, 'CNY'); return price; }
  } catch (e) {}

  // 3) OKX
  try {
    const res = execSync('curl -s "https://www.okx.com/api/v5/market/ticker?instId=USDT-CNH" -A "Mozilla/5.0" 2>/dev/null', { encoding: 'utf-8' });
    const price = parseFloat(JSON.parse(res)?.data?.[0]?.last);
    if (price > 0) { console.log('实时汇率（OKX）1 USDT =', price, 'CNY'); return price; }
  } catch (e) {}

  console.log('汇率获取失败，使用默认值', FALLBACK_RATE);
  return FALLBACK_RATE;
}

// ── Telegram 发送函数 ─────────────────────────────────────
function tgSendText(text) {
  if (!TG_TOKEN || !TG_CHATID) { console.log('[TG] 未配置 botToken/chatId，跳过发送'); return; }
  try {
    const payload = JSON.stringify({ chat_id: TG_CHATID, text, parse_mode: 'HTML' });
    const tmpFile = '/tmp/tg-text-payload.json';
    fs.writeFileSync(tmpFile, payload);
    const res = execSync(
      `curl -s -X POST "https://api.telegram.org/bot${TG_TOKEN}/sendMessage" -H "Content-Type: application/json" -d @${tmpFile}`,
      { encoding: 'utf-8' }
    );
    const r = JSON.parse(res);
    if (r.ok) {
      console.log('[TG] 文字发送成功');
    } else {
      console.error('[TG] 文字发送失败:', r.description);
    }
  } catch (e) {
    console.error('[TG] 文字发送异常:', e.message);
  }
}

function tgSendDocument(filePath, caption) {
  if (!TG_TOKEN || !TG_CHATID) { console.log('[TG] 未配置 botToken/chatId，跳过发送'); return; }
  if (!fs.existsSync(filePath)) { console.error('[TG] 文件不存在:', filePath); return; }
  try {
    let cmd = `curl -s -X POST "https://api.telegram.org/bot${TG_TOKEN}/sendDocument"` +
              ` -F "chat_id=${TG_CHATID}"` +
              ` -F "document=@${filePath}"`;
    if (caption) cmd += ` -F "caption=${caption.replace(/"/g, '\\"')}"`;
    const res = execSync(cmd, { encoding: 'utf-8' });
    const r = JSON.parse(res);
    if (r.ok) {
      console.log('[TG] 文件发送成功:', path.basename(filePath));
    } else {
      console.error('[TG] 文件发送失败:', r.description);
    }
  } catch (e) {
    console.error('[TG] 文件发送异常:', e.message);
  }
}

// ── 登录（网页模拟，通用） ────────────────────────────────
async function loginGetToken(site) {
  const br = await chromium.launch({ executablePath: C, headless: true, args: ['--no-sandbox', '--disable-setuid-sandbox'] });
  const pg = await (await br.newContext()).newPage();
  let tok = null;
  pg.on('response', async r => {
    try { const d = JSON.parse(await r.text()); if (d.data && d.data.token) tok = d.data.token; } catch (e) {}
  });
  await pg.goto(site.loginUrl, { waitUntil: 'networkidle' });
  await pg.waitForTimeout(2000);
  const inp = await pg.$$('input');
  await inp[0].fill(site.username);
  await inp[1].fill(site.password);
  const btnText = site.loginButtonText || '登录';
  for (const b of await pg.$$('button')) {
    if ((await b.textContent()).includes(btnText)) { await b.click(); break; }
  }
  await pg.waitForTimeout(3000);
  await br.close();
  return tok;
}

// ── API 请求 ──────────────────────────────────────────────
function req(apiBase, apiPath, tok) {
  return JSON.parse(execSync(
    `curl -s "${apiBase}${apiPath}" -H "Authorization: Bearer ${tok}" -A "Mozilla/5.0" 2>/dev/null`,
    { encoding: 'utf-8' }
  ));
}

// ── 拉取单游戏全部佣金明细（自动翻页 + 客户端日期过滤） ──
function fetchGameTransactions(apiBase, gameId, startDate, endDate, tok) {
  const rows = [];
  let page = 1;
  while (true) {
    const res = req(apiBase, `/api/admin/developers/transactions?page=${page}&per_page=200&game_id=${gameId}`, tok);
    if (res.code !== 200 || !res.data?.data?.item) break;
    const items = res.data.data.item;
    if (!items || items.length === 0) break;
    rows.push(...items);
    const lastPage = res.data.last_page;
    if (!lastPage || page >= lastPage) break;
    page++;
  }
  return rows.filter(item => {
    const cstDate = toCST(item.created_at).slice(0, 10);
    return cstDate >= startDate && cstDate <= endDate;
  });
}

// ── 佣金比例覆盖 ──────────────────────────────────────────
function applyOverride(gameName, income, originalCommission, originalRatio) {
  if (OVERRIDES[gameName] !== undefined) {
    const ratio = parseFloat(OVERRIDES[gameName]);
    const newCommission = parseFloat((income * ratio).toFixed(2));
    return { commission: newCommission, ratio: (ratio * 100).toFixed(2) + '%', overridden: true };
  }
  return { commission: originalCommission, ratio: originalRatio, overridden: false };
}

// ── 写入 Google Sheet ─────────────────────────────────────
function callGas(gasUrl, payload) {
  const tmpFile = '/tmp/vendor-commission-payload.json';
  fs.writeFileSync(tmpFile, JSON.stringify(payload));
  const red = execSync(
    `curl -s -X POST "${gasUrl}" -H "Content-Type: application/json" -d @${tmpFile} -A "Mozilla/5.0" -D - 2>/dev/null | grep -i "^location:" | tr -d "\r" | awk '{print $2}'`,
    { encoding: 'utf-8' }
  ).trim();
  if (red) return JSON.parse(execSync(`curl -s "${red}" -A "Mozilla/5.0"`, { encoding: 'utf-8' }));
  return JSON.parse(execSync(`curl -s -X POST "${gasUrl}" -H "Content-Type: application/json" -d @${tmpFile} -A "Mozilla/5.0" -L 2>/dev/null`, { encoding: 'utf-8' }));
}

function writeToSheet(gasUrl, spreadsheetId, sheetName, headers, rows) {
  return callGas(gasUrl, { action: 'writeRows', spreadsheet_id: spreadsheetId, sheet_name: sheetName, headers, rows });
}

function clearSheet(gasUrl, spreadsheetId, sheetName) {
  return callGas(gasUrl, { action: 'clearData', spreadsheet_id: spreadsheetId, sheet_name: sheetName });
}

// ── 生成单厂商 Excel ──────────────────────────────────────
// Sheet1=汇总，后续每个游戏一个明细 sheet
// 返回实际写入路径（xlsx 或 csv）
function generateVendorExcel(vendorData, usdtRate, outputPath) {
  const DETAIL_HEADERS = ['ID', '游戏信息', '游戏ID', '流水号', '关联订单', '玩家订单金额', '佣金比例', '佣金', '是否覆盖比例', '交易时间'];
  const xlsxMod = loadXlsx();

  if (xlsxMod) {
    const wb = xlsxMod.utils.book_new();

    // 汇总 sheet
    const summaryRows = [
      ['游戏名称', '佣金（CNY）', '佣金（USDT）'],
      ...vendorData.gameSummary.map(g => [
        g.gameName,
        g.commission.toFixed(2),
        g.commissionUsdt.toFixed(2),
      ]),
      ['总计', vendorData.totalCommission.toFixed(2), vendorData.totalCommissionUsdt.toFixed(2)],
    ];
    xlsxMod.utils.book_append_sheet(wb, xlsxMod.utils.aoa_to_sheet(summaryRows), '汇总');

    // 每个游戏明细 sheet
    for (const game of vendorData.gameResults) {
      if (!game.rows || game.rows.length === 0) continue;
      const sheetData = [DETAIL_HEADERS, ...game.rows];
      const sheetName = fmtSheetName(game.gameName).slice(0, 31);
      xlsxMod.utils.book_append_sheet(wb, xlsxMod.utils.aoa_to_sheet(sheetData), sheetName);
    }

    xlsxMod.writeFile(wb, outputPath);
    return outputPath;
  }

  // 降级：CSV（只含汇总）
  const csvPath = outputPath.replace(/\.xlsx$/, '.csv');
  const lines = ['游戏名称,佣金（CNY）,佣金（USDT）'];
  for (const g of vendorData.gameSummary) {
    lines.push(`${g.gameName},${g.commission.toFixed(2)},${g.commissionUsdt.toFixed(2)}`);
  }
  lines.push(`总计,${vendorData.totalCommission.toFixed(2)},${vendorData.totalCommissionUsdt.toFixed(2)}`);
  fs.writeFileSync(csvPath, '\uFEFF' + lines.join('\n'), 'utf-8');
  return csvPath;
}

// ── 主逻辑 ────────────────────────────────────────────────
async function main() {
  const argv = process.argv.slice(2);
  const isClear      = argv.includes('--clear');
  const isReport     = argv.includes('--report');
  const vendorIdx    = argv.indexOf('--vendor');
  const targetVendor = vendorIdx >= 0 ? argv[vendorIdx + 1] : null;

  const yearIdx  = argv.indexOf('--year');
  const monthIdx = argv.indexOf('--month');
  const now = new Date(Date.now() + 8 * 3600 * 1000);
  let year  = yearIdx  >= 0 ? parseInt(argv[yearIdx  + 1]) : now.getFullYear();
  let month = monthIdx >= 0 ? parseInt(argv[monthIdx + 1]) : now.getMonth() + 1;

  if (yearIdx < 0 && monthIdx < 0 && now.getDate() === 1) {
    const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    year  = lastMonth.getFullYear();
    month = lastMonth.getMonth() + 1;
    console.log('检测到1日，自动切换为上月补跑模式');
  }

  const startDate  = `${year}-${String(month).padStart(2, '0')}-01`;
  const lastDay    = new Date(year, month, 0).getDate();
  const endDate    = `${year}-${String(month).padStart(2, '0')}-${lastDay}`;
  const monthLabel = `${year}年${month}月`;

  console.log(`\n=== 厂商佣金采集 ${monthLabel} ===`);
  console.log(`数据范围：${startDate} ~ ${endDate}`);
  if (isReport) console.log('模式：--report（生成独立 Excel，直接发送到 TG）');
  console.log('');

  const usdtRate = getUsdtRate();
  const HEADERS  = ['ID', '游戏信息', '游戏ID', '流水号', '关联订单', '玩家订单金额', '佣金比例', '佣金', '是否覆盖比例', '交易时间'];

  const reportData = { monthLabel, year, month, usdtRate, vendors: [] };

  for (const site of cfg.sites) {
    if (!site.enabled) continue;
    console.log(`\n====== 站点：${site.name} ======`);

    // --clear 模式
    if (isClear) {
      console.log('清除模式：清空所有 sheet 数据（保留格式）');
      for (const vendor of site.vendors) {
        console.log(`>>> 厂商：${vendor.name}`);
        for (const game of vendor.games) {
          try {
            const r = clearSheet(site.gasWebAppUrl, vendor.spreadsheetId, fmtSheetName(game.name));
            console.log(`    清除 [${game.name}]:`, JSON.stringify(r));
          } catch (e) { console.error(`    清除 [${game.name}] 失败:`, e.message); }
        }
        try {
          const r = clearSheet(site.gasWebAppUrl, vendor.spreadsheetId, '总计');
          console.log(`    清除 [总计]:`, JSON.stringify(r));
        } catch (e) {}
      }
      continue;
    }

    // 登录
    const tok = await loginGetToken(site);
    if (!tok) { console.error(`  ${site.name} 登录失败，跳过`); continue; }
    console.log(`  登录成功\n`);

    for (const vendor of site.vendors) {
      if (targetVendor && vendor.name !== targetVendor && vendor.id !== targetVendor) continue;
      console.log(`>>> 厂商：${vendor.name}`);

      let totalCommission = 0;
      const gameResults   = [];
      const gameSummary   = [];

      for (const game of vendor.games) {
        process.stdout.write(`    ${game.name} (ID:${game.id})... `);
        const items = fetchGameTransactions(site.apiBase, game.id, startDate, endDate, tok);
        console.log(`${items.length} 条`);
        if (items.length === 0) continue;

        let gameCommission = 0;
        const sheetRows = items.map(item => {
          const income    = parseFloat(item.income || 0);
          const origComm  = parseFloat(item.amount || 0);
          const origRatio = (item.display_commission_ratio || '0') + '%';
          const { commission, ratio, overridden } = applyOverride(game.name, income, origComm, origRatio);
          if (item.type === 1) gameCommission += commission;
          return [
            item.id,
            item.game?.name || game.name,
            item.game_id,
            item.transaction_id || '',
            item.business_id   || '',
            income.toFixed(2),
            ratio,
            commission.toFixed(2),
            overridden ? '是（已覆盖）' : '否',
            toCST(item.created_at),
          ];
        });

        gameResults.push({ gameName: game.name, rows: sheetRows, commission: gameCommission });
        gameSummary.push({
          gameName:       game.name,
          commission:     parseFloat(gameCommission.toFixed(2)),
          commissionUsdt: parseFloat((gameCommission / usdtRate).toFixed(2)),
        });
        totalCommission += gameCommission;
      }

      const totalUsdt = parseFloat((totalCommission / usdtRate).toFixed(2));
      console.log(`    总佣金（CNY）：${totalCommission.toFixed(2)}`);
      console.log(`    总佣金（USDT）：${totalUsdt.toFixed(2)}（汇率 ${usdtRate} CNY/USDT）`);

      // 写入 Google Sheet（report 模式跳过）
      if (!isReport) {
        for (const { gameName, rows } of gameResults) {
          try {
            const r = writeToSheet(site.gasWebAppUrl, vendor.spreadsheetId, fmtSheetName(gameName), HEADERS, rows);
            console.log(`    写入 [${gameName}]:`, JSON.stringify(r));
          } catch (e) { console.error(`    写入 [${gameName}] 失败:`, e.message); }
        }
        const summaryHeaders = ['游戏名称', '佣金（CNY）', '佣金（USDT）'];
        const summaryRows = [
          ...gameSummary.map(g => [g.gameName, g.commission.toFixed(2), g.commissionUsdt.toFixed(2)]),
          ['总计', totalCommission.toFixed(2), totalUsdt.toFixed(2)],
        ];
        try {
          const r = writeToSheet(site.gasWebAppUrl, vendor.spreadsheetId, '总计', summaryHeaders, summaryRows);
          console.log(`    写入 [总计]:`, JSON.stringify(r));
        } catch (e) { console.error(`    写入 [总计] 失败:`, e.message); }
      }

      reportData.vendors.push({
        siteName:            site.name,
        vendorName:          vendor.name,
        totalCommission:     parseFloat(totalCommission.toFixed(2)),
        totalCommissionUsdt: totalUsdt,
        usdtRate,
        gameSummary,
        gameResults,
      });

      console.log('');
    }
  }

  // 写 report JSON
  const reportPath = '/tmp/commission-report.json';
  fs.writeFileSync(reportPath, JSON.stringify(reportData, null, 2));
  console.log(`\n📄 报告数据已写入 ${reportPath}`);

  // ── report 模式：生成 Excel + 直接通过 TG Bot 发送 ──
  if (isReport) {
    console.log('\n========== 开始发送到 Telegram ==========');
    for (const v of reportData.vendors) {
      const safeName  = v.vendorName.replace(/[^\w\u4e00-\u9fa5]/g, '_');
      const excelPath = `/tmp/佣金报告_${year}年${month}月_${safeName}.xlsx`;
      const finalPath = generateVendorExcel(v, usdtRate, excelPath);

      // ── 文字摘要（格式固定，不可更改）──
      // 格式：{厂商名}：人民币 XXXXX元，折合XXXXXUSDT
      const summary = `{${v.vendorName}}：人民币 ${v.totalCommission.toFixed(2)}元，折合${v.totalCommissionUsdt.toFixed(2)}USDT`;

      console.log(`发送 ${v.vendorName}...`);
      console.log(`  文字：${summary}`);
      console.log(`  文件：${finalPath}`);

      // 1. 先发文字
      tgSendText(summary);

      // 2. 再发文件（caption 留空，文字已单独发）
      tgSendDocument(finalPath, '');

      // 输出结构化行（供 agent 回复用户时引用）
      console.log(`VENDOR_EXCEL|${v.vendorName}|${summary}|${finalPath}`);
    }

    // ── 输出汇总行（供 agent 直接复制回复，格式固定带 USDT）──
    const allSummaryLines = reportData.vendors.map(v =>
      `• {${v.vendorName}}：人民币 ${v.totalCommission.toFixed(2)}元，折合${v.totalCommissionUsdt.toFixed(2)}USDT`
    ).join('\n');
    const allSummaryText = `${monthLabel}厂商数据：\n${allSummaryLines}`;
    console.log(`SUMMARY_ALL|${allSummaryText}`);
    console.log('==========================================');
  }

  console.log('\n=== 完成 ===');
}

main().catch(e => { console.error('错误:', e.message); process.exit(1); });

