// Google Apps Script - 厂商佣金月报写入
// 部署为 Web App（任何人可访问），将 URL 填入 commission-monthly.js 的 WEBAPP_URLS

function doPost(e) {
  try {
    const payload = JSON.parse(e.postData.contents);
    const result = handleRequest(payload);
    return ContentService.createTextOutput(JSON.stringify(result)).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ success: false, error: err.message })).setMimeType(ContentService.MimeType.JSON);
  }
}

function handleRequest(payload) {
  if (payload.action === 'writeMonthlyCommission') {
    return writeMonthlyCommission(payload);
  }
  return { success: false, error: 'unknown action: ' + payload.action };
}

function writeMonthlyCommission(p) {
  const ss = SpreadsheetApp.openById(p.spreadsheet_id);

  // 获取或新建 sheet
  let sheet = ss.getSheetByName(p.sheet_name);
  if (sheet) {
    sheet.clearContents();
  } else {
    sheet = ss.insertSheet(p.sheet_name);
  }

  // ── 第一部分：游戏汇总（A1:B区域）──
  // A1: 游戏信息  B1: 佣金（人民币）
  sheet.getRange('A1').setValue('游戏信息');
  sheet.getRange('B1').setValue('佣金（人民币）');

  // A2~An: 各游戏名 + 对应佣金
  const summary = p.game_summary || [];
  for (let i = 0; i < summary.length; i++) {
    sheet.getRange(i + 2, 1).setValue(summary[i].name);
    sheet.getRange(i + 2, 2).setValue(summary[i].commission);
  }

  // A9: 总佣金（人民币）  B9: 数值
  sheet.getRange('A9').setValue('总佣金（人民币）');
  sheet.getRange('B9').setValue(p.total_commission_cny);

  // A10: 总佣金（USDT）  B10: 数值
  sheet.getRange('A10').setValue('总佣金（USDT）');
  sheet.getRange('B10').setValue(p.total_commission_usdt);

  // A11: 汇率说明
  sheet.getRange('A11').setValue('汇率：1 USDT = ' + p.usdt_rate + ' CNY');

  // ── 第二部分：明细表头（第12行）──
  const headers = p.headers || ['ID','游戏信息','游戏ID','流水号','关联订单','玩家订单金额','佣金比例','佣金','交易时间'];
  sheet.getRange(12, 1, 1, headers.length).setValues([headers]);

  // ── 第三部分：明细数据（第13行起）──
  const rows = p.rows || [];
  if (rows.length > 0) {
    sheet.getRange(13, 1, rows.length, headers.length).setValues(rows);
  }

  // ── 格式美化 ──
  // 表头加粗
  sheet.getRange('A1:B1').setFontWeight('bold');
  sheet.getRange(12, 1, 1, headers.length).setFontWeight('bold').setBackground('#f3f3f3');

  // 总佣金行加粗
  sheet.getRange('A9:B10').setFontWeight('bold');

  // 自动列宽
  for (let col = 1; col <= headers.length; col++) {
    sheet.autoResizeColumn(col);
  }

  return {
    success: true,
    sheet: p.sheet_name,
    rows_written: rows.length,
    total_cny: p.total_commission_cny,
    total_usdt: p.total_commission_usdt
  };
}

